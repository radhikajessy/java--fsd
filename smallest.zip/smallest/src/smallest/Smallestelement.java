package smallest;
// fourth smallest element

public class Smallestelement {
	
	public static void main(String[] args) {
		 int arr[]= {2,1,14,6,15,9,5,8};
		 int temp,size;
		 size=arr.length; 
		 System.out.println("Array size is  "+size);
		 for(int i=0;i<size;i++) {
			 for(int j=i+1;j<size;j++) {
				 if(arr[i]<arr[j]) {
					 temp=arr[i];
					 arr[i]=arr[j];
					 arr[j]=temp;
				 }
			 }
		 }
		 System.out.println();
		 System.out.println("elements of array in decending order");
		 for(int i=0;i<size;i++) {
			 System.out.println(arr[i]+ " ");
			 
		 }
		 System.out.println("fourth smallest number is "+arr[size-4]);
		 
	}
}