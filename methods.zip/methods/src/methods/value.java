package methods;

//call by value

public class value {
	 int a;
	 int b;
	 
	 static void add(int s, int t) {
		 s=20;
		 System.out.println("result is: "+(s+t));
		 
	 }
	 public static void main(String[] args) {
		 value v1=  new value();
		 v1.a=3;v1.b=5;
		 System.out.println("before passing: "+(v1.a+v1.b));
		 add(v1.a,v1.b);
		 System.out.println("after passing: "+(v1.a+v1.b));
		 
	 }

}
