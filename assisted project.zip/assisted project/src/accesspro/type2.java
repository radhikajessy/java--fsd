package accesspro;

public class type2 {

	public static void main(String[] args) {
		type1 t= new type1();
		System.out.println(t.n);
		System.out.println(t.name);
		
// In protected method we can access data from with in and outside the class.
// and also we can access from another new package through inheritance only.
		
	}

}
