package collections;
import java.util.*;
public class main {
	public static void main(String[] args) {
		List<String> a1 = new ArrayList<>();
		a1.add("abhishek");
		a1.add("raj");
		a1.add("mani");
		
		Iterator itr = a1.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
		
		}

	
}
