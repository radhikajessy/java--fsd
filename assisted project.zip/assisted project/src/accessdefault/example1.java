package accessdefault;

// default modifier 1

class example1 {
	 
	int number = 100;
	String name = "cat";
	
	void show() {
		System.out.println("This is default method");
		
	}
	example1(){
		System.out.println("this is java");
		
	}
	public static void main(String[] args) {
		example1 e= new example1();
        System.out.println(e.number);
        System.out.println(e.name);
        e.show();
// we can access data from within the class and outside the class within the same package.
//but we are not able to access from another new package.
		
	}
	
	
	

}
