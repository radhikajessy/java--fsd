import java.util.Scanner;

class main {

	public static void main(String[] args) {
		Scanner obj=new Scanner(System.in);
		try {
			System.out.println("enter the value of a and b");
			int a= obj.nextInt();
			int b= obj.nextInt();
			int c= a/b;
			System.out.println("divide = " +c);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}

}
