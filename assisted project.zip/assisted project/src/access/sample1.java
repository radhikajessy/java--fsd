package access;

//private modifier 1

class sample1 {   
	 private int a = 10;
	 private String name = "nick";
	  
	 private sample1() {
		 System.out.println("welcome nick");
	 }

	 
    public static void main(String[] args) {
    	sample1 s= new sample1();
    	System.out.println(s.a);
    	System.out.println(s.name);
    	
    	
		 
	 }
}
