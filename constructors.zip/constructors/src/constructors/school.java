package constructors;
// parameterized constructor

public class school {

	int a;
	String b;
	
	school(int c, String d){
		a=c;
		b=d;
	}
	 public static void main (String[] args)
	 {
		 school s = new school(34, " moon");
		 school s1 = new school(55," white");
		 System.out.println(s.a+s.b);
		 System.out.println(s1.a+s1.b);
			
	 }
	
	 }
 	
