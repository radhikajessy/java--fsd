package map;
import java.util.HashMap;
import java.util.Map;

public class Hashmap {
	
	public static void main(String[] args) {
		Map<String,String> Map= new HashMap<>();
		Map.put("myname","ram");
		Map.put("actor","jason");
		
		System.out.println(Map);
		
	}

}
