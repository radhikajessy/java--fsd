package access;

// private modifier 2

public class sample2 {
	
	public static void main (String[] args) {
		//sample1 s = new sample1();
		//System.out.println(s.a);
		//System.out.println(s.name);
		
// we cannot access data from sample 1. it will give error.
//because in private modifier  it will be accessed with in the class only not outside the class.
	}

}
