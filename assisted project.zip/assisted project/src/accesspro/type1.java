package accesspro;

// protected modifier

public class type1 {
	
	protected int n=20;
	protected String name = "dog";
	
	
	protected type1() {
		System.out.println("this is protected method");
		
	}
	public static void main (String[] args) {
		type1 t= new type1();
		System.out.println(t.n);
		System.out.println(t.name);
		
	}
	
	

}
