package throwkeywords;
// custom exception

public class CustomException extends Exception{
	String str;
	CustomException(String str){
		this.str=str;
		
	}
	public String toString() {
		return("Hi friend "+str);
	}
	
	public class Testexception {
		public static void main(String[] args) {
			try {
				throw new CustomException(" how are you");
				
			}catch(Exception e) {
				System.out.println(e);
			}
		}

	}
}
