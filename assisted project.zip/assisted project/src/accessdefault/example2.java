package accessdefault;

 // default modifier 2

class example2 {
	
	public static void main(String[] args) {
		example1 e = new example1();
		System.out.println(e.number);
		System.out.println(e.name);
		e.show();
	//	
		
	}
	

}
