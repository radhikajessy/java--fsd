package casting;

public class explicit {

	public static void main(String[] args) {
	
// explicit  conversion - larger data type to smaller data type
	
		long l1 = 100000;
		int a1 = (int)l1;
		
		long l2 = 20000;
		byte b = (byte)l2;
		
		long l3 = 456;
		double d = (double)l3;
		 
		long l4 = 70;
		char c=(char)l4;
		
		System.out.println(a1);
		System.out.println(b);
		System.out.println(d);
		System.out.println(c);
		
		
		
		
		
		

	}

}
