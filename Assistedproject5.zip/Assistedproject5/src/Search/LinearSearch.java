package Search;

	import java.util.Scanner;
	public class LinearSearch {

		public static void main(String[] args) {
			int []arr = {2,5,8,13,56,7,9};
			Scanner sc= new Scanner(System.in);
			System.out.println( "enter the element to search");		
			int target =sc.nextInt();
			int position=-1;
		    for(int i=0;i<arr.length;i++) {
					if(arr[i]==target) {
						position=i;
						break;
					}
				}
				if(position!=-1)
						System.out.println( target+" found at position "+(position));
				else
					System.out.println( target + "not found");
					}
			
				}
	       




