

public class Sleep{
public static void main(String[] args) {
	System.out.println("thread its too late");
	try 
	{
		Thread.sleep(1000);
		
		
	}
	catch(InterruptedException e)
	{
		System.out.println("Thread Interrupted");
		
	}
	System.out.println("thread get up");


}

}

