package accesspub1;

import accesspub.practice1;

public class practice3 {

	public static void main(String[] args) {
		practice1 p= new practice1();
		System.out.println(p.n);
		System.out.println(p.name);
		
// we can access  data from anywhere.
//without any restrictions by using public.
	}

}
