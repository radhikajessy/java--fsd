package matrix;

public class Matrixmultiplication {

	
	public static void main(String[] args) {
		int m1[][]= {
				        {1,3,3},
				        {8,5,6},
				        {7,6,9}
		             };
		int m2[][]= {
		                 {2,3},
		                 {6,7},
		                 {4,9}
                     };
		
		int res[][] = new int[3][2];
		int sum=0;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
	
			{
				for(int k=0;k<3;k++)
				{
					sum = sum+m1[i][k]*m2[k][j];
					
				}
				res[i][j]=sum;
				sum=0;
			}

		}
		
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++) {
				System.out.println(res[i][j]+"  ");
			}
			System.out.println();
	    }
	}
}
