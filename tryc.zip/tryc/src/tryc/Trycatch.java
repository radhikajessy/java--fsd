package tryc;

// try catch statement
public class Trycatch {

	public static void main(String[] args) {
		try 
		{
			int d=10/0;// infinity
			System.out.println("100");
		}
		catch(Exception e) {
			System.out.println(e);
			System.out.println(2);
			
		}
		finally {
			System.out.println("java is fun");
			
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
