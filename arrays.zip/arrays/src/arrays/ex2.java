package arrays;
// multi dimensional

public class ex2 {

	public static void main(String[] args) {
		int a[][]= {{34,56},{23,54},{12,6}};
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++) {
				System.out.println("a[" +i+ " ][" +j+ "]="+a[i][j]);
			}
		}

	}

}
