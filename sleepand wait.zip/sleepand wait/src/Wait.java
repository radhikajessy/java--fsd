
public class Wait {
	public static void main(String[] args) {
		System.out.println("Good to see you");
		synchronized(args) {
			System.out.println("welcome to java");
			
		try 
		{
			args.wait(1000);
		
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("end");
		}
	}
}

	



