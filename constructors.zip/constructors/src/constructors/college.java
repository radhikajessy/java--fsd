package constructors;
// default constructor

public class college {
	
	int a;
	String b;
	 public static void main (String[] args)
	 {
		 college c = new college();
		 System.out.println(c.a+c.b);
		 //constructor is automatically taken without arguments
	 }
		
	}

