package Search;

import java.util.Scanner;
public class BinarySearch {
	public static  int BinarySearch(int[]arr, int searchItem) {
		int start =0;
		int end =arr.length-1;
		while(start<=end)
		{
			int mid =(start+end)/2;
			if(searchItem==arr[mid])
			{
				return mid;
				
			}
			else if(searchItem<arr[mid])
			{
				end =mid-1;
				
			}
			else 
			{
				start=mid+1;
				
			}
			
		}
		return -1;
	}
		
	public static void main(String[] args) {
		System.out.println(" element to search");
		Scanner sc = new Scanner(System.in);
		int searchItem=sc.nextInt();
		int[] arr = {3,5,6,12,17,9,10,56,98};
		int result=BinarySearch(arr,searchItem);
		if(result<0)
		{
			System.out.println(searchItem+"is not found");
			
		}
		else
		{
			System.out.println( searchItem+" is found at index:"+result);
		}
	}
	

}
