package practice;

public class MyThread  extends Thread {
	public void run() {
		
		for( int i=0;i<=5;i++) {
		System.out.println(i);
		System.out.println("welcome to thread");
		}
		
	}
	public static void main(String[] args) {
		MyThread obj= new MyThread();
		obj.start();
		System.out.println("thread");
	}

}
