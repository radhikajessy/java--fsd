package accesspub;

public class practice2 {

	public static void main(String[] args){
		practice1 p= new practice1();
		System.out.println(p.n);
		System.out.println(p.name);
		}

}
