package casting;

public class implicit {
public static void main(String[] args) {
	
// implicit conversion - smaller data type to larger data type
	
	byte b = 10;
	short s = (short)b;
	
	byte b1= 25;
	float f = (float)b1;
	
	double d = 45.3f;
	int a = (int)d;
	
	char c ='R';
	int a1 = (int)c;
	
	double d1  = 36.22;
	long l = (long)d1;
	
	System.out.println(s);
	System.out.println(f);
	System.out.println(a);
	System.out.println(a1);
	System.out.println(l);
	
	
	
	
	
	
	
	
	
	
			
	
	
	
	
}
	
	
	
	

}
