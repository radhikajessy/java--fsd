abstract class Anonymousclassexam{
	public abstract void display();
}
public class Outclass{
	public static void main(String[] args) {
		 Anonymousclassexam inclass = new  Anonymousclassexam(){
			 public void display() {
				 System.out.println("this is the inner class");
				 
			 }
			 
		 };
		 inclass.display();
	}
}
		 
		
	
		
	
	
	
	
		
		



		

