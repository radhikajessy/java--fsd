package accesspro1;// new package
// By inheritance

import accesspro.type1;

 class type3 extends type1 {

	public static void main(String[] args) {
		type3 t= new type3();
		System.out.println(t.n);
		System.out.println(t.name);

	}

}
