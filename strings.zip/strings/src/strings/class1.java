package strings;
// strings
public class class1 {
	
	public static void main(String[] args) {
		StringBuffer r= new StringBuffer("learn coding");
		System.out.println(r.reverse());
		
		StringBuilder ref=new StringBuilder("java coding");
		System.out.println(ref.reverse());
}

}
