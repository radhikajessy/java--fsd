package accesspub;

// public modifier

public class practice1 {
	
	public int n = 100;
	public String name = "wow";
	
	public practice1() {
		System.out.println("this is public method");
	}
	
	public static void main (String[] args) {
		practice1 p= new practice1();
		System.out.println(p.n);
		System.out.println(p.name);
		
}
	
	

}
