package throwkeywords;

public class Finally {
	public static void main(String[] args) {
	try 
	{
		int d=5/0;
		System.out.println("100");
	}
	catch(Exception e) {
		System.out.println(e);
		System.out.println(2);
		
	}
	finally {
		System.out.println(" hello welcome to new world+");
		
	}

	}
}


